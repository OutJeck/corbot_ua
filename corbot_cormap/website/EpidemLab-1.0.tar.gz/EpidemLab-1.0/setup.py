from setuptools import setup

setup(name='EpidemLab',
      version='1.0',
      description='Simulate the spread of the disease with your parameters!',
      license='GPL-3.0',
      packages=['epidemlab'],
      zip_safe=False,
      include_package_data=True)
